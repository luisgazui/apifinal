$(function(){
     $('#datatable').DataTable({
     	responsive: true,
            "language": {
                "emptyTable"    : "No se encontraron datos en la tabla",
                "info"          : "Viendo _START_ a _END_ de _TOTAL_ entradas",
                "infoEmpty"     : "Viendo 0 a 0 de 0 entradas",
                "infoFiltered"  : "(filtrado de _MAX_ entradas)",
                "infoPostFix"   : "",
                "thousands"     : ",",
                "lengthMenu"    : "Ver _MENU_ Entradas",
                "loadingRecords": "Cargando Datos...",
                "processing"    : "Procesando Datos...",
                "search"        : "Buscar:",
                "zeroRecords"   : "No se encontraron datos en la búsqueda",
                "paginate"      : {
                    "first"   : "Primero",
                    "last"    : "Último",
                    "next"    : "Siguiente",
                    "previous": "Anterior"
                },
                "aria": {
                    "sortAscending" : ": activate to sort column ascending",
                    "sortDescending": ": activate to sort column descending"
                }
            },
            //"lengthMenu"    : [lengthMenu,lengthMenu]

     });   
 });

function class_funciones(){
	this.inicio_ajax = function(sec,title){
	    if(sec == undefined) sec = 10;
	    if(title == undefined) title = "Espere Por Favor";
	    $.blockUI
	        ({
	            css: {
	            border: 'none',
	            padding: '20px',
	            backgroundColor: '#000',
	            '-webkit-border-radius': '10px',
	            '-moz-border-radius': '10px',
	            opacity: .5,
	            color: '#fff',
	            '-webkit-border-radius': '10px',
	            '-moz-border-radius': '10px',
	        },

	            message: "<h4>"+title+"</h4> <img src='public/img/ajax-loader.gif' /> "
	        });
	       setTimeout($.unblockUI, sec * 100);
	}

	this.mostrar_div = function(id,sec){
	    if(id == undefined) id = "";
	    if(sec == undefined){ sec = 3; }
	    $(id).show();
	    $('html,body').animate({scrollTop: $(id).position().top}, 800, 'swing');

	    return false;
	}

	this.enviarMensaje = function(){
    	obj_funciones.inicio_ajax();
    	setTimeout(function(){
	    	 $.ajax({
		        type: $("#formcontacto").attr('method'),
	   			url: $("#formcontacto").attr('action'),
	   			data: $("#formcontacto").serialize(),
		        cache : false,
	            async : false,
		        dataType: 'json',
		    success: function(data){
		    	if(data.success == true){   
	                $("#msj_alert").html(data.mensages);
	                obj_funciones.mostrar_div("#msj_alert");
	                $('#formcontacto')[0].reset();
	            }
	            else{
	                $("#msj_alert").html(data.mensages);
	                 obj_funciones.mostrar_div("#msj_alert");
	            }
	         }  
           }); 
	     },200);	
	}

	this.enviarMensajeMultiples = function(){
    	obj_funciones.inicio_ajax();

    	var formData = new FormData($("#formmulti")[0]);

    	setTimeout(function(){
	    	 $.ajax({
		        type: 'POST',
	   			url: 'librerias/wa_api_php_simple_multi.php',
	   			data: formData,
		        cache : false,
	            async : false,
	            contentType: false,
	        	processData: false,
		        dataType: 'json',
		    success: function(data){
		    	if(data.success == true){   
	                $("#msj_alert").html(data.mensages);
	                obj_funciones.mostrar_div("#msj_alert");
	                $('#formmulti')[0].reset();
	            }
	            else{
	                $("#msj_alert").html(data.mensages);
	                 obj_funciones.mostrar_div("#msj_alert");
	            }
	         }  
           }); 
	     },200);	
	}

	this.modal = function(id,url,div,modal){
	 if(modal == undefined) modal = "";
	  $.ajax({
	      type: 'POST',
	      url: url,
	      data: id,
	      beforeSend: function (){
	           $(modal).modal({ keyboard:true}, 'show');
	           $(div).html('Cargando <i class="fa fa-refresh fa-spin"></i>');
	      },
	      success: function(data){
	            if(data != ""){
	                if(modal != "")
	                    $(modal).modal('show');
	                    $(div).html(data);
	           }
	      },
	  });
	}

	 this.borrar = function(url,datos){ 
      if(confirm('¿Realmente Desea Eliminar Este Mensaje?'))
      {
        obj_funciones.inicio_ajax();
        setTimeout(function()
        { 
          $.ajax({
	        type: 'POST',
	        url: url,
	        data: datos,
	        cache : false,
            async : false,
            dataType: 'json',
	        success: function(data){
	           	
	           	if(data.success == true){   
	           			
           			$("#msj_alert_table").html(data.mensages);
                 	obj_funciones.mostrar_div("#msj_alert_table");	
           			setTimeout(function(){
           				window.location = 'apiwasalida.php';
           			},500);

	           	}else{
	           		$("#msj_alert_table").html(data.mensages);
                 	obj_funciones.mostrar_div("#msj_alert_table");
	           	}
	        }
 		  }); 	        
         },300); 
       }
  }

  this.borrardirectorio = function(url,datos){ 
      if(confirm('¿Realmente Desea Eliminar Este Email?'))
      {
        obj_funciones.inicio_ajax();
        setTimeout(function()
        { 
          $.ajax({
	        type: 'POST',
	        url: url,
	        data: datos,
	        cache : false,
            async : false,
            dataType: 'json',
	        success: function(data){
	           	
	           	if(data.success == true){   
	           			
           			$("#msj_alert_table").html(data.mensages);
                 	obj_funciones.mostrar_div("#msj_alert_table");	
           			setTimeout(function(){
           				window.location = 'email-directorio.php';
           			},500);

	           	}else{
	           		$("#msj_alert_table").html(data.mensages);
                 	obj_funciones.mostrar_div("#msj_alert_table");
	           	}
	        }
 		  }); 	        
         },300); 
       }
  }

  this.enviarEmail = function(){
    	
    	var messageLength = CKEDITOR.instances['form_message'].getData().replace(/<[^>]*>/gi, '').length;
        if(!messageLength){
            alert('Por favor Ingrese un Mensaje');
        }else{
        obj_funciones.inicio_ajax();
    	setTimeout(function(){
	    	 $.ajax({
		        type:$("#formemail").attr('method'),
	   			url: $("#formemail").attr('action'),
	   			data: $("#formemail").serialize(),
		        cache : false,
	            async : false,
		        dataType: 'json',
		    success: function(data){
		    	if(data.success == true){   
	                $("#msj_alert").html(data.mensages);
	                obj_funciones.mostrar_div("#msj_alert");
	                $('#formemail')[0].reset();
	            }
	            else{
	                $("#msj_alert").html(data.mensages);
	                 obj_funciones.mostrar_div("#msj_alert");
	            }
	         }  
           }); 
	     },200);
		        	
        }	     	
	}

	this.borrarEmailEnviado = function(url,datos){ 
      if(confirm('¿Realmente Desea Eliminar Este Email?'))
      {
        obj_funciones.inicio_ajax();
        setTimeout(function()
        { 
          $.ajax({
	        type: 'POST',
	        url: url,
	        data: datos,
	        cache : false,
            async : false,
            dataType: 'json',
	        success: function(data){
	           	
	           	if(data.success == true){   
	           			
           			$("#msj_alert_table").html(data.mensages);
                 	obj_funciones.mostrar_div("#msj_alert_table");	
           			setTimeout(function(){
           				window.location = 'email-enviado.php';
           			},500);

	           	}else{
	           		$("#msj_alert_table").html(data.mensages);
                 	obj_funciones.mostrar_div("#msj_alert_table");
	           	}
	        }
 		  }); 	        
         },300); 
       }
  }

  this.directorios = function(){ 
        obj_funciones.inicio_ajax();
        setTimeout(function()
        { 
          $.ajax({
	        type: $("#formdirectorio").attr('method'),
	   		url: $("#formdirectorio").attr('action'),
	   		data: $("#formdirectorio").serialize(),
	        cache : false,
            async : false,
            dataType: 'json',
	        success: function(data){
	           	
	           	if(data.success == true){   
	           			
           			$("#msj_alert").html(data.mensages);
                 	obj_funciones.mostrar_div("#msj_alert");	
           			setTimeout(function(){
           				window.location = 'email-directorio.php';
           			},600);

	           	}else{
	           		$("#msj_alert").html(data.mensages);
                 	obj_funciones.mostrar_div("#msj_alert");
	           	}
	        }
 		  }); 	        
         },300); 
  }

  	this.setselect2 = function(div)
	{
	    $.fn.select2.defaults.set("theme", "bootstrap");
	    $(div).select2({
	        placeholder: "Seleccionar",
	        language: "es",
	        //allowClear: true,
	    });
	}
}
var obj_funciones = new class_funciones();