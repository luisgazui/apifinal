var /**@const{!string}*/pdfjs_version = "v1.0.907";
