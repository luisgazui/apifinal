<?php 
    $host = "localhost";
    $base = "bigsender";
    $user = "root";
    $pass = "123456";
    //conectamos
    $conexion = mysqli_connect($host,$user,$pass, $base);
    if(!$conexion){
      	die("Connection failed: " . mysqli_connect_error());
    }
?>

