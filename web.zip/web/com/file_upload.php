<?php
sleep(3);
require(dirname(__FILE__) . '/librerias/ajaxuploader/Uploader.php');

// Directory where we're storing uploaded images
// Remember to set correct permissions or it won't work
$upload_dir = 'whatsapp/upload/files';
$valid_extensions = array('gif', 'png', 'jpeg', 'jpg', 'mp4','3gp');
$Upload = new FileUpload('uploadfile');
// Handle the upload
$result = $Upload->handleUpload($upload_dir, $valid_extensions);

if (!$result){
    echo json_encode(array('success' => false, 'msg' => $Upload->getErrorMsg()));   
} else {
    echo json_encode(array('success' => true, 'file' => $Upload->getFileName()));
}