<?php  
$sql = "SELECT *
FROM whatsappapi";

$consulta = mysqli_query($conexion, $sql);
if(mysqli_num_rows($consulta)>0){

  $contar = mysqli_num_rows($consulta);
}
else{
   $contar = 0;
  echo "No hay Resultados";
}
?>

<!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
              <div class="row font-wow" style="margin-top: 25px">
                 <div class="col-md-12">
                  <h2><i class="fa fa-whatsapp" aria-hidden="true"></i> Mensajes de Entrada</h2>
                 </div> 
                 <a href="javascript:void(0)" download="Descarga.xls" href="#" onclick="return ExcellentExport.excel(this, 'datatable', 'Salidad');"><i class="fa fa-file-excel-o"></i> Exportar Excel</a>
                 <table class="table table-bordered text-center" id="datatable">
                  <thead>
                    <tr> 
                      <th class="text-center">Destino</th>
                      <th class="text-center">Telefono</th>
                      <th class="text-center">Mensaje</th>
                      <th class="text-center">Fecha Recibido</th>
                    </tr>  
                  </thead>
                    <tbody>
                   <?php
                      //while($filas = mysqli_fetch_assoc($consulta)){
                      ?>
                
                     <tr>
                      <td class="text-center"> No hay Mensajes Recibidos
                      </td>
                    
                    
                     </tr> 
                  
                    <?php //} ?>
                    </tbody>
                </table>
                <div class="text-info text-center">
                Mostrando: <?php echo $contar ?>
                </div>
              </div>
            </div> 
        </div>              