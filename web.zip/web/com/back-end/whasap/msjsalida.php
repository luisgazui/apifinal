<?php  
$sql = "SELECT *
FROM whatsappapi";

$consulta = mysqli_query($conexion, $sql);
if(mysqli_num_rows($consulta)>0){

  $contar = mysqli_num_rows($consulta);
}
else{
   $contar = 0;
  echo "No hay Resultados";
}
?>

<!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
              <div class="row font-wow" style="margin-top: 25px"> <div class="table-responsive">
                 <div class="col-md-12">
                  <h2><i class="fa fa-whatsapp" aria-hidden="true"></i> Mensajes de Salida</h2>
                   <div id="msj_alert_table"></div>
                 </div> 
                
                  <a href="javascript:void(0)" download="Descarga.xls" href="#" onclick="return ExcellentExport.excel(this, 'datatable', 'Salidad');"><i class="fa fa-file-excel-o"></i> Exportar Excel</a>
                 <table class="table table-bordered text-center" id="datatable">
                  <thead>
                    <tr> 
                      <th class="text-center">Destino</th>
                      <th class="text-center">Telefono</th>
                      <th class="text-center">Mensaje</th>
                      <th class="text-center">Fecha Enviado</th>
                      <th class="text-center">Estatus</th>
                      <th class="text-center">Opciones</th>
                    </tr>  
                  </thead>
                    <tbody>
                   <?php
                      while($filas = mysqli_fetch_array($consulta)){
                      ?>

                     <tr>
                    
                      <td><?php echo utf8_encode($filas['pais']) ?></td>
                      <td><?php echo utf8_encode($filas['telefono']) ?></td>
                      <td><?php echo utf8_encode($filas['mensaje']) ?></td>
                      <td><?php echo utf8_encode($filas['fecha_create']) ?></td>
                      <td><?php echo utf8_encode($filas['estado']) ?></td>
                      <td><a href="#" onclick="obj_funciones.borrar('apiwasalidaeliminar.php', 'id=<?php echo $filas['id'] ?>')" title="Eliminar"><i class="fa fa-trash" aria-hidden="true"></i></a></td>
                     </tr> 
                  
                   <?php } ?>
                   </tbody>
                </table>
                 </div>
              </div>
            </div> 
        </div>              