<?php  
$sql = "SELECT *
FROM paises";
$consulta = mysqli_query($conexion, $sql);
?>
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row font-wow" style="margin-top: 25px">
                 <div class="col-md-12">
                  <h2><i class="fa fa-whatsapp" aria-hidden="true"></i> Bienvenido al Módulo Whatsapp - Multiples Mensajes</h2>
                 </div> 
                  <div id="msj_alert"></div>  

                   <form action="librerias/wa_api_php_simple_multi.php" method="POST" id="formmulti" onsubmit="obj_funciones.enviarMensajeMultiples(); return false;" autocomplete="off"> 
                    <div class="col-md-12">
                  <div>
                  <!-- Nav tabs -->
                  <ul class="nav nav-tabs" role="tablist">
                    <li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">Inicio</a></li>
                    <li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">Imagenes o video</a></li>

                    <li><a target="blank_" href="formatoexcel/formatomulti.csv">Descargar Formato</a></li>
                  </ul>

                  <!-- Tab panes -->
                  <div class="tab-content">
                    <div role="tabpanel" class="tab-pane active" id="home">
                         <br>  
                        <div class="col-md-6">
                          <div class="form-group">
                            <label style="font-size: 15px" for="form_phone">País</label>
                            <select name="pais" class="form-control">
                            <option value="" selected="">Seleccione</option>
                             <?php
                              while($filas = mysqli_fetch_array($consulta)):
                              ?>
                                <option value="<?php echo $filas['pais']; ?>, <?php echo $filas['codigo'];?>"><?php echo $filas['pais'] ?>
                                  </option>
                              <?php endwhile; ?>
                                  <option value="Venezuela, 58">Venezuela</option>
                            </select>
                          </div>  
                        </div>  

                        <div class="col-md-6">
                          <div class="form-group">
                            <label style="font-size: 15px" for="form_phone">Archivo Excel Multiple</label>
                            <input id="form_phone" type="file" name="excelnum" class="form-control">
                          </div>  
                        </div>  
                        <div class="col-md-12">
                         <div class="form-group">
                            <label style="font-size: 15px" for="form_message">Mensaje</label>
                            <textarea id="form_message" name="message" class="form-control" placeholder="No mas de 3000 caracteres..." rows="7" maxlength="3000"></textarea>
                            
                            <!--
                            <input type="hidden" name="cedular" value="584147470012">
                            <div style="margin-top: 10px"></div>
                            <!-- elegir el adecuado segun la cantidad de caracteres -->
                            <br>

                             
                        </div>
                      </div>
                       <div class="col-md-12 text-center">
                            <span class="badge text-center">Max<div id="restanumero">3000</div></span>
                       </div>
                    </div>

                    <div role="tabpanel" class="tab-pane" id="profile">
                        <br>
                        <div class="col-md-12 text-center well">
                             <button id="uploadBtn" class="btn btn-large btn-primary"><i class="fa fa-upload" aria-hidden="true"></i> Elegir Archivo</button>
                             PNG, JPG, GIF, MP4, 3GP
                             <input type="hidden" name="file" id="filedata">
                        </div>
                        <div class="col-md-12 text-center">
                              <div id="progressOuter" class="progress progress-striped active" style="display:none;">
                                <div id="progressBar" class="progress-bar progress-bar-success"  role="progressbar" aria-valuenow="45" aria-valuemin="0" aria-valuemax="100" style="width: 0%">
                                </div>
                              </div>
                            </div>
       
                              <div class="row" style="padding-top:10px;">
                                  <div id="msgBox">
                                  </div>
                              </div>
             
                            <hr>  
                    </div>
                  
                  </div>
                  </div>
                </div>
            </div>

                <div style="margin-top: 20px" class="col-md-12 text-center">
                <button class="btn btn-success btn-send" type="submit"><i class='fa fa-envelope-o'></i> Enviar Mensaje</button>
                   
                </div>
                    </form> 
                </div>

                    <!-- /.col-lg-12 -->
            </div>
                <!-- /.row -->
        </div>
            <!-- /.container-fluid -->

 <script src="public/js/SimpleAjaxUploader.js"></script>
<script>
function escapeTags( str ) {
  return String( str )
           .replace( /&/g, '&amp;' )
           .replace( /"/g, '&quot;' )
           .replace( /'/g, '&#39;' )
           .replace( /</g, '&lt;' )
           .replace( />/g, '&gt;' );
}

window.onload = function() {

  var btn = document.getElementById('uploadBtn'),
      progressBar = document.getElementById('progressBar'),
      progressOuter = document.getElementById('progressOuter'),
      msgBox = document.getElementById('msgBox');

  var uploader = new ss.SimpleUpload({
        button: btn,
        url: 'file_upload.php',
        //sessionProgressUrl: 'librerias/ajaxuploader/sessionProgress.php',
        progressUrl: 'librerias/ajaxuploader/uploadProgress.php',
        name: 'uploadfile',
        multipart: true,
        maxSize: 1024,
        hoverClass: 'ui-state-hover',
        focusClass: 'ui-state-focus',
        disabledClass: 'ui-state-disabled',   
        responseType: 'json',
        startXHR: function() {
            progressOuter.style.display = 'block'; // make progress bar visible
            this.setProgressBar( progressBar );
        },
        onSubmit: function() {
            msgBox.innerHTML = ''; // empty the message box
            btn.innerHTML = 'Cargando...'; // change button text to "Uploading..."
          },
        onComplete: function( filename, response ) {
            btn.innerHTML = 'Elegir Archivo';
            progressOuter.style.display = 'none'; // hide progress bar when upload is completed

            if ( !response ) {
                msgBox.innerHTML = 'Unable to upload file';
                return;
            }

            if (response.success === true ) {
                msgBox.innerHTML = '<br><div class="col-md-12 text-center"><img src="whatsapp/upload/files/'+escapeTags( filename )+'" style="width: 150px; border: 1px solid rgb(204, 204, 204);"></div><br><div class="col-md-12 text-center"><strong><a target="_blank" href="whatsapp/upload/files/'+escapeTags( filename )+'">' + escapeTags( filename ) + '</a></strong>' + ' <div class="text-success"><i class="fa fa-check" aria-hidden="true"></i> cargado con éxito..</div></div>';
                $('#filedata').val(escapeTags( filename ));

            } else {
                if ( response.msg )  {
                    msgBox.innerHTML = escapeTags( response.msg );

                } else {
                    msgBox.innerHTML = 'An error occurred and the upload failed.';
                }
            }
          },
        onError: function() {
            progressOuter.style.display = 'none';
            msgBox.innerHTML = 'Unable to upload file';
          }
    });
};
</script>

<script type="text/javascript">
$(document).ready(function() {
 
    var total_letras = 3000;
 
    $('#form_message').keyup(function() {
    var longitud = $(this).val().length;
    var resto = total_letras - longitud;
    $('#restanumero').html(resto);
    if(resto <= 0){
        $('#form_message').attr("maxlength", 3000);
    }
    });
});
</script>