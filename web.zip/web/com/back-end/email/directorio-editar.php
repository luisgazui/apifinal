<?php  
$sql = "SELECT * from email  
         WHERE id = ".$_GET['id'].";";
$consulta = mysqli_query($conexion, $sql);         
?>
<?php
      while($filas = mysqli_fetch_array($consulta)):
?>
  <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row font-wow" style="margin-top: 25px">
                 <div class="col-md-12">
                  <h2><i class="fa fa-envelope-o" aria-hidden="true"></i> Directorio Editar E-mail</h2>
                 </div> 
                  <div id="msj_alert"></div>  

                   <form action="librerias/actualizar-directorio.php" method="POST" id="formdirectorio" onsubmit="obj_funciones.directorios(); return false;" autocomplete="off"> 
                    <div class="col-md-12">
                  <div>
                  <!-- Nav tabs -->
                  <ul class="nav nav-tabs" role="tablist">
                    <li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">Inicio</a></li>
                  </ul>

                  <!-- Tab panes -->
                  <div class="tab-content">
                    <div role="tabpanel" class="tab-pane active" id="home">
                         <br>  
                        <div class="col-md-6">
                          <div class="form-group">
                            <label style="font-size: 15px" for="emailform">E-mail</label>
                            <input type="email" name="email" class="form-control" id="emailform" value="<?php echo $filas['email'] ?>" required>
                          </div>  
                        </div>  

                        <div class="col-md-6">
                          <div class="form-group">
                            <label style="font-size: 15px" for="form_phone">Nombre y Apellido</label>
                            <input id="form_phone" type="tel" name="nombres" class="form-control" placeholder="Nombres y Apellido" value="<?php echo $filas['nombre'] ?>" required>
                          </div>  
                        </div>  
                        <div class="col-md-12">
                         <div class="form-group">
                            <label style="font-size: 15px" for="form_message">Observación</label>

                            <textarea value="hola" id="form_message" name="mensaje"maxlength="300" rows="5" class="form-control"><?php echo $filas['observacion'] ?></textarea>
                            <input type="hidden" name="id" value="<?php echo $_GET['id'] ?>">
                            <br> 
                        </div>
                      </div>
                    </div>
                  </div>

                </div>
            </div>
                <div style="margin-top: 20px" class="col-md-12 text-center">
                <div class="form-group">
                <button class="btn btn-success btn-send" type="submit"><i class='fa fa-envelope-o'></i> Actualizar</button></div>
                   
                </div>
                    </form> 
                </div>

                    <!-- /.col-lg-12 -->
            </div>
                <!-- /.row -->
        </div>
        <?php endwhile; ?>
            <!-- /.container-fluid -->