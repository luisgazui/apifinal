<?php  
$sql = "SELECT *
FROM emailsalida";

$consulta = mysqli_query($conexion, $sql);
if(mysqli_num_rows($consulta)>0){

  $contar = mysqli_num_rows($consulta);
}
else{
   $contar = 0;
  echo "No hay Resultados";
}
?>

<!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
              <div class="row font-wow" style="margin-top: 25px"> <div class="table-responsive">
                 <div class="col-md-12">
                  <h2><i class="fa fa-envelope-o" aria-hidden="true"></i> Enviados</h2>
                   <div id="msj_alert_table"></div>
                 </div> 
                
                  <a href="javascript:void(0)" download="Descarga.xls" href="#" onclick="return ExcellentExport.excel(this, 'datatable', 'Salidad');"><i class="fa fa-file-excel-o"></i> Exportar Excel</a>

                 <table class="table table-bordered text-center" id="datatable">
                  <thead>
                    <tr> 
                      <th class="text-center">Para</th>
                      <th class="text-center">De</th>
                      <th class="text-center">Asunto</th>
                      <th class="text-center">Mensaje</th>
                      <th class="text-center">Estado</th>
                      <th class="text-center">fecha_create</th>
                      <th class="text-center">Opciones</th>
                    </tr>  
                  </thead>
                    <tbody>
                   <?php
                      while($filas = mysqli_fetch_array($consulta)){
                      ?>
                     <tr>
                    
                      <td><?php echo utf8_encode(str_replace(',', '<br>', $filas['para'])) ?></td>
                      <td><?php echo utf8_encode($filas['de']) ?></td>
                      <td><?php echo utf8_encode($filas['asunto']) ?></td>
                      <td><?php echo utf8_encode($filas['mensaje']) ?></td>
                       <td><?php echo utf8_encode($filas['estado']) ?></td>
                        <td><?php echo utf8_encode($filas['fecha_create']) ?></td>
                      <td>
                      <a href="#" onclick="obj_funciones.borrarEmailEnviado('librerias/eliminar-enviado.php', 'id=<?php echo $filas['id'] ?>')" title="Eliminar"><i class="fa fa-trash" aria-hidden="true"></i></a>
                      <a href="email-mensaje-renviar.php?id=<?php echo $filas['id'] ?>" title="Reenviar"><i class="fa fa-envelope" aria-hidden="true"></i></a>
                      </td>
                     </tr> 
                  
                   <?php } ?>
                   </tbody>
                </table>
                 </div>
              </div>
            </div> 
        </div>              