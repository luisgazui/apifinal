  <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row font-wow" style="margin-top: 25px">
                 <div class="col-md-12">
                  <h2><i class="fa fa-envelope-o" aria-hidden="true"></i> Directorio Nuevo E-mail</h2>
                 </div> 
                  <div id="msj_alert"></div>  

                   <form action="librerias/registrar-nuevo-directorio.php" method="POST" id="formdirectorio" onsubmit="obj_funciones.directorios(); return false;" autocomplete="off"> 
                    <div class="col-md-12">
                  <div>
                  <!-- Nav tabs -->
                  <ul class="nav nav-tabs" role="tablist">
                    <li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">Inicio</a></li>
                  </ul>

                  <!-- Tab panes -->
                  <div class="tab-content">
                    <div role="tabpanel" class="tab-pane active" id="home">
                         <br>  
                        <div class="col-md-6">
                          <div class="form-group">
                            <label style="font-size: 15px" for="emailform">E-mail</label>
                            <input type="email" name="email" class="form-control" id="emailform" required>
                          </div>  
                        </div>  

                        <div class="col-md-6">
                          <div class="form-group">
                            <label style="font-size: 15px" for="form_phone">Nombre y Apellido</label>
                            <input id="form_phone" type="tel" name="nombres" class="form-control" placeholder="Nombres y Apellido" required>
                          </div>  
                        </div>  
                        <div class="col-md-12">
                         <div class="form-group">
                            <label style="font-size: 15px" for="form_message">Observación</label>
                            <textarea onselect="" id="form_message" name="mensaje" on placeholder="Observación" maxlength="300" rows="5" class="form-control"></textarea>
  
                            <br> 
                        </div>
                      </div>
                    </div>
                  </div>

                </div>
            </div>
                <div style="margin-top: 20px" class="col-md-12 text-center">
                <div class="form-group">
                <button class="btn btn-success btn-send" type="submit"><i class='fa fa-envelope-o'></i> Guardar</button></div>
                   
                </div>
                    </form> 
                </div>

                    <!-- /.col-lg-12 -->
            </div>
                <!-- /.row -->
        </div>
            <!-- /.container-fluid -->