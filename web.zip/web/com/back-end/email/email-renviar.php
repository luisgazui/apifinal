<?php  
$sql1 = "SELECT * from emailsalida  
         WHERE id = ".$_GET['id'].";";
$consulta1 = mysqli_query($conexion, $sql1);  
 
$sql2 = "SELECT *
FROM email";
$consulta2 = mysqli_query($conexion, $sql2);

?>
<?php
      while($filas2 = mysqli_fetch_array($consulta1)):
?>


        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row font-wow" style="margin-top: 25px">
                 <div class="col-md-12">
                  <h2><i class="fa fa-envelope-o" aria-hidden="true"></i> Reenviar E-Mail</h2>
                 </div> 
                  <div id="msj_alert"></div>  

                   <form action="librerias/reemviar-email.php" method="POST" id="formemail" onsubmit="obj_funciones.enviarEmail(); return false;" autocomplete="off"> 
                    <div class="col-md-12">
                  <div>
                  <!-- Nav tabs -->
                  <ul class="nav nav-tabs" role="tablist">
                    <li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">Inicio</a></li>
                  </ul>

                  <!-- Tab panes -->
                  <div class="tab-content">
                    <div role="tabpanel" class="tab-pane active" id="home">
                         <br>  
                        <div class="col-md-6">
                          <div class="form-group">
                            <label style="font-size: 15px" for="email">Emails</label>
                            <select name="email[]" class="form-control" id="email" multiple="" required>
                             <?php
                              while($filas = mysqli_fetch_array($consulta2)):
                              ?>
                                <?php if($filas['email'] != NULL): ?>
                                <option selected="<?php echo  $filas2['email'] ?>" value="<?php echo  $filas['email'] ?>"><?php echo  $filas['email'] ?>
                                  </option>
                                  <?php else: ?>
                                    <option value="<?php echo  $filas['email'] ?>"><?php echo  $filas['email'] ?>
                                  </option>
                                  <?php endif; ?>
                              <?php endwhile; ?>
                                
                            </select>
                          </div>  
                        </div>  

                        <div class="col-md-6">
                          <div class="form-group">
                            <label style="font-size: 15px" for="form_phone">De:</label>
                            <input id="form_phone" type="tel" name="de" class="form-control" value="<?php echo $filas2['de'] ?>" placeholder="Correo de Usuario de la Sección" required>
                          </div>  
                        </div> 
                        <div class="col-md-12">
                          <div class="form-group">
                            <label style="font-size: 15px" for="asunto">Asunto</label>
                            <input id="form_phone" type="tel" name="asunto" class="form-control" value="<?php echo $filas2['asunto'] ?>" placeholder="Ingrese el Asunto" required>
                          </div>  
                        </div>   
                        <div class="col-md-12">
                         <div class="form-group">
                            <label style="font-size: 15px" for="form_message">Redactar Mensaje</label>
                            <textarea id="form_message" name="message" required maxlength="3000"><?php echo $filas2['mensaje'] ?></textarea>
                            <input type="hidden" name="id" value="<?php echo $filas2['id'] ?>">
                            <br> 
                        </div>
                      </div>
                    </div>
                  </div>

                </div>
            </div>
                <div style="margin-top: 20px" class="col-md-12 text-center">
                <div class="form-group">
                <button class="btn btn-success btn-send" type="submit"><i class='fa fa-envelope-o'></i> Reenviar Email</button></div>
                   
                </div>
                    </form> 
                </div>

                    <!-- /.col-lg-12 -->
            </div>
                <!-- /.row -->
        </div>
            <!-- /.container-fluid -->
          <?php endwhile; ?>  
<script type="text/javascript">
  $(document).ready(function()
  {
    obj_funciones.setselect2('#email');
  });   
  
     CKEDITOR.replace('form_message', {
      /*filebrowserBrowseUrl : 'public/responsive_filemanager/filemanager/dialog.php?type=2&editor=ckeditor&fldr=',
      filebrowserUploadUrl : 'public/responsive_filemanager/filemanager/dialog.php?type=2&editor=ckeditor&fldr=',
      filebrowserImageBrowseUrl : 'public/responsive_filemanager/filemanager/dialog.php?type=1&editor=ckeditor&fldr=',*/
      width : "auto",
      height : "10em",
      language: 'es',
      allowedContent : true,
      entities : false,
      filebrowserBrowseUrl : 'public/responsive_filemanager/filemanager/dialog.php?type=2&editor=ckeditor&fldr=',
      filebrowserUploadUrl : 'public/responsive_filemanager/filemanager/dialog.php?type=2&editor=ckeditor&fldr=',
      filebrowserImageBrowseUrl : 'public/responsive_filemanager/filemanager/dialog.php?type=1&editor=ckeditor&fldr=',
      toolbar: [
           ['Undo','Redo'], //,'-','Bold','Italic', 'NumberedList','BulletedList','-','Outdent','Indent','Blockquote'],
           ['JustifyLeft','JustifyCenter','JustifyRight','JustifyBlock'],
           ['Image','Table','Link','Unlink','HorizontalRule','SpecialChar','PageBreak'],
           ['Cut','Copy','Paste','PasteText','PasteFromWord'],
           ['Find','Replace','-','SelectAll','RemoveFormat'],
           ['SpellChecker', 'Scayt'],
           [ 'Bold', 'Italic', 'RemoveFormat'],
           ['NumberedList', 'BulletedList', '-', 'Outdent', 'Indent', '-', 'Blockquote' ],
           [ 'Format'],
           [ 'Maximize', 'selection', 'Source','spellchecker'],
        ]
      });

      function actualizarCK()
      {
        for (instance in CKEDITOR.instances )
        CKEDITOR.instances[instance].updateElement();
        $('textarea').trigger('keyup');
      }
</script>