<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row font-wow" style="margin-top: 25px">
            <div class="col-md-12">
               <h1>Bienvenido Al Panel de Control</h1>
            </div>
        </div>

            <!-- /.col-lg-12 -->
    </div>
        <!-- /.row -->
</div>

