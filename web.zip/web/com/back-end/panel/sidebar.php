
            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav font-wow" id="side-menu">
                        <li>
                            <a href="#"><i class="fa fa-comments fa-fw"></i> SMS<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="/sms">Envio de SMS</a>
                                </li>
                                <li>
                                    <a href="#">Bandeja de Salida</a>
                                </li>
                                <li>
                                    <a href="/sms/masivos">Directorio</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                    <!-- /.nav-second-level -->
                </li>
                <li>
                    <a href="#"><i class="fa fa-whatsapp fa-fw"></i> Whatsapp<span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">
                        <li>
                            <a href="apiwa.php">Professional Whatsapp</a>
                        </li>
                        <li>
                            <a href="apiwaentrada.php">Bandeja de Entrada</a>
                        </li>
                        <li>
                            <a href="apiwasalida.php">Bandeja de Salida</a>
                        </li>

                         <li>
                            <a href="apiwamulti.php">Multiples Mensajes</a>
                        </li>
                    </ul>
                    <!-- /.nav-second-level -->
                </li>
                <li>
                    <a href="#"><i class="fa fa-envelope-o fa-fw"></i> Email<span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">
                        <li>
                            <a href="apiemail.php">Professional Email</a>
                        </li>
                        <li>
                            <a href="email-directorio.php">Directorio</a>
                        </li>
                        <li>
                            <a href="email-enviado.php">Enviados</a>
                        </li>
                       
                    </ul>
                    <!-- /.nav-second-level -->
                </li>
                <li>
                    <a href="#"><i class="fa fa-microphone fa-fw"></i> Notas de Voz<span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">
                        <li>
                            <a href="flot.html">Professional Voise</a>
                        </li>
                        <li>
                            <a href="morris.html">Directorio</a>
                        </li>
                        <li>
                            <a href="morris.html">Borradores</a>
                        </li>
                        <li>
                            <a href="morris.html">Registro</a>
                        </li>
                    </ul>
                    <!-- /.nav-second-level -->
                </li>
            </ul>
        </div>
        <!-- /.sidebar-collapse -->
    </div>
    <!-- /.navbar-static-side -->
</nav>