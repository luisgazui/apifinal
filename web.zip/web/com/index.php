<?php  
//Plantilla para el Login
require_once('back-end/login/head.php');

require_once('back-end/login/section.php');

require_once('back-end/login/footer.php');
?>