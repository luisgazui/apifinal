<?php 
include_once('conexion/conexion.php'); 
?>
<div id="wrapper">
<?php  
//Plantilla para el Admin
	session_start();
    $_SESSION['app'] = '7';  
    if (!isset($_SESSION['id'])){
        header('Location: /');;
    }
require_once('back-end/panel/head.php');
require_once('back-end/panel/nav_top.php');
require_once('back-end/panel/sidebar.php');
require_once('back-end/whasap/msjsalida.php');
require_once('back-end/panel/footer.php');
?>
</div>
 