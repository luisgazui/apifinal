   <!-- /#wrapper -->

    <!-- jQuery -->

    <!-- Bootstrap Core JavaScript -->
    <script src="public/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="public/js/metisMenu.min.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="public/js/sb-admin-2.js"></script>
    <script src="public/js/select2.min.js"></script>
    <script src="public/js/Scripts/excellentexport.js"></script>
    <script src="public/js/jquery.dataTables.min.js"></script>
    <script src="public/js/dataTables.bootstrap.min.js"></script>

    <script src="public/js/ajaxload.js"></script>
    <script src="public/js/funciones.js"></script>

</body>

</html>
