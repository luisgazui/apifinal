<?php  
//Plantilla para el Login
//	session_start();
    $_SESSION['app'] = '7';  
    if (!isset($_SESSION['id'])){
        header('Location: /');;
    }
require_once('back-end/login/head.php');

require_once('back-end/login/section.php');

require_once('back-end/login/footer.php');
?>