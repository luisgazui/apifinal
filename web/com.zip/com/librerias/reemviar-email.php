<?php 
include_once('../conexion/conexion.php'); 
$emails = NULL;
foreach ($_POST['email'] as $r){
	 $emails.=$r.",";
}
$emails = substr($emails,0,strlen($emails)-1);
$para = $emails;
$titulo = $_POST['asunto'];
$mensaje = '
<html>
<head>
  <title>'.$_POST['asunto'].'</title>
</head>
<body>
  '.$_POST['message'].'
</body>
</html>
';
$cabeceras = 'MIME-Version: 1.0' . "\r\n";
$cabeceras .= 'Content-type: text/html; charset=utf-8' . "\r\n";
$cabeceras .= 'From: '.$_POST['de'].'>';
$enviado = mail($para, $titulo, $mensaje, $cabeceras);

if($enviado){

		$sql = "UPDATE emailsalida set para='$emails',de='$_POST[de]',asunto='$_POST[asunto]' WHERE id='$_POST[id]'";		

		if (mysqli_query($conexion, $sql)) {
		    $find_sql = "SELECT ncreditos FROM `creditosapp` WHERE app_id= '".$_SESSION['app']."'";
		    $consulta = mysqli_query($conexion, $find_sql);
		    while($filas = mysqli_fetch_array($consulta)){
		       $costo = $filas['ncreditos'];
		    }
                $update_query = "INSERT INTO `cuenta` (`egreso`, 
                                                       `usuario_id`) 
                                                      VALUES 
                                                      ('$costo', '".$_SESSION['id']."')";
                    $consulta = mysqli_query($conexion, $update_query);
                    $find_sql = "SELECT
                                Sum(a.ingreso) - Sum(a.egreso) AS total
                                FROM
                                cuenta AS a
                                WHERE
                                a.usuario_id = '".$_SESSION['id']."'";
                    $consulta = mysqli_query($conexion, $find_sql);
                    
                    while($filas = mysqli_fetch_array($consulta)){
                       $_SESSION['total'] = $value['total'];
                       //$session->set('total', $value['total']);
                    }

		echo json_encode(array('success' => true, 'mensages' => '<div class="col-md-12 text-center"><div class="alert alert-success alert-dismissible" role="alert">
  			<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>Email Reenviado Correctamente</div></div>'));
		}else{
			echo 'error al insertar';
		}
}else{
	echo json_encode(array('success' => false, 'mensages' => '<div class="col-md-12 text-center"><div class="alert alert-danger alert-dismissible" role="alert">
  			<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>Error no se pudo Enviar Intentelo de Nuevo</div></div>'));
}

?>